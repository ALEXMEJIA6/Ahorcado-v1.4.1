package jvmdipoo;

import java.awt.*;
import javax.swing.*;

/**
 * Pantalla: Elige el modo de juego (Clásico / Arcade-Beta bloqueado).
 */
public class jvIntModoJuego extends JInternalFrame {

    private jvAhorcado parent;

    public jvIntModoJuego(jvAhorcado parent) {
        this.parent = parent;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        PanelFondo fondo = new PanelFondo(new Color(15,10,5), new Color(38,20,8));
        fondo.setLayout(new BorderLayout());

        JPanel decoracion = buildDecoración();

        // ── Escudo / pergamino de título ─────────────────────────────────────
        JPanel pergamino = EstiloUI.panelPergamino();
        pergamino.setLayout(new BoxLayout(pergamino, BoxLayout.Y_AXIS));
        pergamino.setBorder(BorderFactory.createEmptyBorder(18,50,22,50));

        JLabel lblTitulo = new JLabel("<html><center>ELIGE EL MODO<br>DE JUEGO</center></html>", SwingConstants.CENTER);
        lblTitulo.setFont(EstiloUI.fuenteTitulo(28));
        lblTitulo.setForeground(new Color(60,30,5));
        lblTitulo.setAlignmentX(CENTER_ALIGNMENT);
        pergamino.add(lblTitulo);
        pergamino.add(Box.createVerticalStrut(18));

        JButton btnClasico = EstiloUI.botonMadera("Jugar Modo Clásico");
        btnClasico.setAlignmentX(CENTER_ALIGNMENT);
        btnClasico.addActionListener(e -> parent.mostrarTema());
        pergamino.add(btnClasico);
        pergamino.add(Box.createVerticalStrut(12));

        JButton btnArcade = EstiloUI.botonMadera("Modo Arcade (Beta)");
        btnArcade.setAlignmentX(CENTER_ALIGNMENT);
        btnArcade.setEnabled(false);
        btnArcade.setToolTipText("Próximamente disponible");
        pergamino.add(btnArcade);

        pergamino.setPreferredSize(new Dimension(360, 250));

        JPanel contenedor = new JPanel(new GridBagLayout());
        contenedor.setOpaque(false);
        // Empujar un poco hacia abajo
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 0; gbc.insets = new Insets(60,0,0,0);
        contenedor.add(pergamino, gbc);

        JLayeredPane capas = new JLayeredPane();
        capas.setPreferredSize(new Dimension(860,580));
        decoracion.setBounds(0,0,860,580);
        contenedor.setBounds(0,0,860,580);
        capas.add(decoracion, JLayeredPane.DEFAULT_LAYER);
        capas.add(contenedor, JLayeredPane.PALETTE_LAYER);

        fondo.add(capas, BorderLayout.CENTER);
        setContentPane(fondo);
    }

    private JPanel buildDecoración() {
        JPanel p = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Arco de fondo
                g2.setColor(new Color(60,48,38));
                g2.fillArc(120,10,620,440,0,180);
                g2.setColor(new Color(85,70,55));
                g2.setStroke(new BasicStroke(12));
                g2.drawArc(120,10,620,440,0,180);

                // Piedras del arco
                g2.setColor(new Color(75,62,48));
                g2.setStroke(new BasicStroke(2));
                for (int i=0;i<14;i++) {
                    double ang = Math.PI*i/13.0;
                    int cx=(int)(430-315*Math.cos(ang));
                    int cy=(int)(230-220*Math.sin(ang));
                    g2.drawRect(cx-16,cy-11,32,22);
                }

                // Horca pequeña decorativa izquierda
                g2.setColor(EstiloUI.MADERA_OSCURA);
                g2.setStroke(new BasicStroke(7,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                g2.drawLine(100,480,100,300); g2.drawLine(70,480,130,480);
                g2.drawLine(100,300,150,300);
                g2.setStroke(new BasicStroke(3));
                g2.setColor(new Color(180,150,80));
                g2.drawLine(150,300,150,325); g2.drawOval(143,323,14,14);

                // Antorchas
                drawAntorcha(g2,780,260); drawAntorcha(g2,50,260);

                // Suelo
                g2.setColor(new Color(40,30,20)); g2.fillRect(0,480,860,100);
                g2.setColor(new Color(55,42,30)); g2.setStroke(new BasicStroke(1));
                for(int x=0;x<860;x+=70) g2.drawLine(x,480,x+35,580);
                for(int y=480;y<580;y+=35) g2.drawLine(0,y,860,y);

                // Cadenas
                g2.setColor(new Color(120,120,120)); g2.setStroke(new BasicStroke(3));
                for(int i=0;i<8;i++){ g2.drawOval(10+i%2*9,80+i*22,16,14); g2.drawOval(820+i%2*9,80+i*22,16,14); }

                g2.dispose();
            }
            private void drawAntorcha(Graphics2D g2,int x,int y){
                g2.setColor(new Color(255,140,0,200)); g2.fillOval(x-10,y-28,20,32);
                g2.setColor(new Color(255,220,0,150)); g2.fillOval(x-6,y-36,12,24);
                g2.setColor(EstiloUI.MADERA_OSCURA); g2.setStroke(new BasicStroke(6));
                g2.drawLine(x,y,x,y+45); g2.setStroke(new BasicStroke(3));
                g2.drawLine(x,y+45,x+18,y+45);
            }
        };
        p.setOpaque(false);
        return p;
    }
}
