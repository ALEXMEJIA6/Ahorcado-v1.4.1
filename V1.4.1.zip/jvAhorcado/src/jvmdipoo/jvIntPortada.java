package jvmdipoo;

import java.awt.*;
import javax.swing.*;

/**
 * Pantalla de portada con fondo de mazmorra, título y botón Continuar.
 */
public class jvIntPortada extends JInternalFrame {

    private jvAhorcado parent;

    public jvIntPortada(jvAhorcado parent) {
        this.parent = parent;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setFrameIcon(null);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        // Panel de fondo degradado oscuro tipo mazmorra
        PanelFondo fondo = new PanelFondo(
                new Color(18, 10, 5),
                new Color(40, 22, 10));
        fondo.setLayout(new BorderLayout());

        // ── Área de dibujo central (horca + título) ──────────────────────────
        JPanel centro = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Dibujar horca decorativa grande
                g2.setColor(new Color(90,55,20));
                g2.setStroke(new BasicStroke(10, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                // Base
                g2.drawLine(340,460,540,460);
                // Palo vertical
                g2.drawLine(440,460,440,100);
                // Palo horizontal
                g2.drawLine(440,100,580,100);
                // Cuerda
                g2.setStroke(new BasicStroke(4));
                g2.setColor(new Color(180,150,80));
                g2.drawLine(580,100,580,145);
                // Lazo
                g2.drawOval(570,142,20,20);

                // Luces de antorcha (círculos naranjas)
                drawAntorcha(g2, 80, 200);
                drawAntorcha(g2, 760, 200);

                // Cadenas decorativas
                g2.setColor(new Color(120,120,120));
                g2.setStroke(new BasicStroke(3));
                for (int i=0;i<6;i++) {
                    g2.drawOval(50+i%2*8,120+i*18,14,12);
                    g2.drawOval(740+i%2*8,120+i*18,14,12);
                }

                // Suelo de piedra
                g2.setColor(new Color(55,45,35));
                g2.fillRect(0,460,getWidth(),getHeight()-460);
                g2.setColor(new Color(70,58,45));
                g2.setStroke(new BasicStroke(1));
                for(int x=0;x<getWidth();x+=60) g2.drawLine(x,460,x+30,getHeight());
                for(int y=460;y<getHeight();y+=30) g2.drawLine(0,y,getWidth(),y);

                g2.dispose();
            }

            private void drawAntorcha(Graphics2D g2, int x, int y) {
                // llama
                g2.setColor(new Color(255,140,0,180));
                g2.fillOval(x-12,y-35,24,40);
                g2.setColor(new Color(255,220,0,140));
                g2.fillOval(x-7,y-42,14,30);
                // palo
                g2.setColor(new Color(120,80,30));
                g2.setStroke(new BasicStroke(6));
                g2.drawLine(x,y,x,y+50);
                // soporte
                g2.setStroke(new BasicStroke(4));
                g2.drawLine(x,y+50,x+20,y+50);
            }
        };
        centro.setOpaque(false);
        centro.setPreferredSize(new Dimension(860,480));

        // ── Título sobre el panel ────────────────────────────────────────────
        JLabel titulo = new JLabel("EL AHORCADO", SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                        RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth()-fm.stringWidth(getText()))/2;
                // Brillo dorado detrás
                g2.setColor(new Color(255,200,0,60));
                g2.setFont(getFont().deriveFont(Font.BOLD, 72f));
                g2.drawString(getText(), tx-1, fm.getAscent()+1);
                // Sombra
                g2.setColor(new Color(0,0,0,200));
                g2.drawString(getText(), tx+3, fm.getAscent()+3);
                // Texto principal
                g2.setColor(EstiloUI.DORADO);
                g2.drawString(getText(), tx, fm.getAscent());
                g2.dispose();
            }
        };
        titulo.setFont(EstiloUI.fuenteTitulo(72));
        titulo.setForeground(EstiloUI.DORADO);
        titulo.setBounds(0, 30, 860, 90);
        centro.add(titulo);

        // Subtítulo
        JLabel sub = new JLabel("¿Puedes adivinar la palabra?", SwingConstants.CENTER);
        sub.setFont(EstiloUI.fuenteTitulo(20));
        sub.setForeground(EstiloUI.CREMA);
        sub.setBounds(0, 118, 860, 30);
        centro.add(sub);

        // ── Panel inferior con botón ─────────────────────────────────────────
        JPanel panelBot = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 12));
        panelBot.setOpaque(false);

        JButton btnContinuar = EstiloUI.botonMadera("CONTINUAR");
        btnContinuar.setPreferredSize(new Dimension(250, 52));
        btnContinuar.setFont(EstiloUI.fuenteBoton(20));
        btnContinuar.addActionListener(e -> parent.mostrarCrearUsuario());
        panelBot.add(btnContinuar);

        fondo.add(centro, BorderLayout.CENTER);
        fondo.add(panelBot, BorderLayout.SOUTH);

        setContentPane(fondo);
    }
}
