package jvmdipoo;

import java.awt.*;
import javax.swing.*;

public class jvIntEscenario extends JInternalFrame {

    private jvAhorcado parent;
    private int tema;

    public jvIntEscenario(jvAhorcado parent, int tema) {
        this.parent = parent;
        this.tema   = tema;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        PanelFondo fondo = new PanelFondo(new Color(15,10,5), new Color(38,20,8));
        fondo.setLayout(new BorderLayout());

        // Titulo
        JPanel panelTitulo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelTitulo.setOpaque(false);
        panelTitulo.setBorder(BorderFactory.createEmptyBorder(20,0,0,0));
        JPanel perg = EstiloUI.panelPergamino();
        perg.setLayout(new FlowLayout());
        perg.setBorder(BorderFactory.createEmptyBorder(10,40,10,40));
        JLabel lblTit = new JLabel("Elige tu Escenario");
        lblTit.setFont(EstiloUI.fuenteTitulo(30));
        lblTit.setForeground(new Color(60,30,5));
        perg.add(lblTit);
        panelTitulo.add(perg);

        // Panel de los 3 mapas
        JPanel panelMapas = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 20));
        panelMapas.setOpaque(false);

        panelMapas.add(crearTarjeta(
            "MAZMORRA",
            "Dificultad: FACIL",
            "Palabras cortas · 6 intentos",
            new Color(30,15,40),
            new Color(100,220,100),
            e -> parent.mostrarEscenarioMazmorra(tema)
        ));

        panelMapas.add(crearTarjeta(
            "NAUFRAGIO",
            "Dificultad: MEDIA",
            "Palabras largas · 6 intentos",
            new Color(10,20,50),
            new Color(100,180,255),
            e -> parent.mostrarEscenarioMar(tema)
        ));

        panelMapas.add(crearTarjeta(
            "BOSQUE",
            "Dificultad: DIFICIL",
            "Palabras largas · solo 3 intentos",
            new Color(10,25,10),
            new Color(255,100,100),
            e -> parent.mostrarEscenarioBosque(tema)
        ));

        fondo.add(panelTitulo, BorderLayout.NORTH);
        fondo.add(panelMapas,  BorderLayout.CENTER);
        setContentPane(fondo);
    }

    private JPanel crearTarjeta(String nombre, String dif, String desc,
                                 Color fondoColor, Color accentColor,
                                 java.awt.event.ActionListener accion) {
        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(fondoColor);
        tarjeta.setBorder(BorderFactory.createLineBorder(accentColor, 3));
        tarjeta.setPreferredSize(new Dimension(220, 280));

        tarjeta.add(Box.createVerticalStrut(20));

        JLabel lblNombre = new JLabel(nombre, SwingConstants.CENTER);
        lblNombre.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblNombre.setForeground(accentColor);
        lblNombre.setAlignmentX(CENTER_ALIGNMENT);
        tarjeta.add(lblNombre);

        tarjeta.add(Box.createVerticalStrut(15));

        JLabel lblDif = new JLabel(dif, SwingConstants.CENTER);
        lblDif.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblDif.setForeground(Color.WHITE);
        lblDif.setAlignmentX(CENTER_ALIGNMENT);
        tarjeta.add(lblDif);

        tarjeta.add(Box.createVerticalStrut(8));

        JLabel lblDesc = new JLabel("<html><center>" + desc + "</center></html>", SwingConstants.CENTER);
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblDesc.setForeground(new Color(180,180,180));
        lblDesc.setAlignmentX(CENTER_ALIGNMENT);
        tarjeta.add(lblDesc);

        tarjeta.add(Box.createVerticalStrut(25));

        JButton btn = EstiloUI.botonMadera("Seleccionar");
        btn.setAlignmentX(CENTER_ALIGNMENT);
        btn.addActionListener(accion);
        tarjeta.add(btn);

        tarjeta.add(Box.createVerticalStrut(20));

        return tarjeta;
    }
}
