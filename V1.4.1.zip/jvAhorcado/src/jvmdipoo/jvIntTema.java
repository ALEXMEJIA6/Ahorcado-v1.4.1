package jvmdipoo;

import java.awt.*;
import javax.swing.*;

/**
 * Pantalla: Tema de generación (Objetos / Cultura General / Ciencia).
 */
public class jvIntTema extends JInternalFrame {

    private jvAhorcado parent;

    public jvIntTema(jvAhorcado parent) {
        this.parent = parent;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        PanelFondo fondo = new PanelFondo(new Color(12,8,3), new Color(35,18,6));
        fondo.setLayout(new BorderLayout());

        JPanel deco = buildDecoración();

        JPanel pergamino = EstiloUI.panelPergamino();
        pergamino.setLayout(new BoxLayout(pergamino, BoxLayout.Y_AXIS));
        pergamino.setBorder(BorderFactory.createEmptyBorder(18,50,22,50));

        JLabel lblModo = new JLabel("Modo Clásico", SwingConstants.CENTER);
        lblModo.setFont(EstiloUI.fuenteBoton(14));
        lblModo.setForeground(new Color(100,60,20));
        lblModo.setAlignmentX(CENTER_ALIGNMENT);
        pergamino.add(lblModo);
        pergamino.add(Box.createVerticalStrut(4));

        JLabel lblTitulo = new JLabel("Tema de Generación", SwingConstants.CENTER);
        lblTitulo.setFont(EstiloUI.fuenteTitulo(26));
        lblTitulo.setForeground(new Color(55,28,5));
        lblTitulo.setAlignmentX(CENTER_ALIGNMENT);
        pergamino.add(lblTitulo);
        pergamino.add(Box.createVerticalStrut(16));

        String[] temas = {"OBJETOS","CULTURA GENERAL","CIENCIA"};
        for (int i=0; i<temas.length; i++) {
            final int idx = i;
            JButton btn = EstiloUI.botonMadera(temas[i]);
            btn.setAlignmentX(CENTER_ALIGNMENT);
            btn.addActionListener(e -> parent.mostrarEscenario(idx));
            pergamino.add(btn);
            if (i < temas.length-1) pergamino.add(Box.createVerticalStrut(10));
        }

        pergamino.setPreferredSize(new Dimension(360, 290));

        JPanel contenedor = new JPanel(new GridBagLayout());
        contenedor.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy=0; gbc.insets=new Insets(50,0,0,0);
        contenedor.add(pergamino, gbc);

        JLayeredPane capas = new JLayeredPane();
        capas.setPreferredSize(new Dimension(860,580));
        deco.setBounds(0,0,860,580);
        contenedor.setBounds(0,0,860,580);
        capas.add(deco, JLayeredPane.DEFAULT_LAYER);
        capas.add(contenedor, JLayeredPane.PALETTE_LAYER);

        fondo.add(capas, BorderLayout.CENTER);
        setContentPane(fondo);
    }

    private JPanel buildDecoración() {
        JPanel p = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Fondo de pared de piedra
                g2.setColor(new Color(55,45,35));
                for(int x=0;x<860;x+=80){
                    for(int y=0;y<580;y+=40){
                        int offset = (y/40%2)*40;
                        g2.setColor(new Color(48+(int)(Math.random()*8),38+(int)(Math.random()*6),28+(int)(Math.random()*5)));
                        g2.fillRect(x+offset,y,78,38);
                        g2.setColor(new Color(30,22,14));
                        g2.drawRect(x+offset,y,78,38);
                    }
                }

                // Arco central
                g2.setColor(new Color(65,52,40));
                g2.fillArc(110,5,640,460,0,180);
                g2.setColor(new Color(90,72,55));
                g2.setStroke(new BasicStroke(14));
                g2.drawArc(110,5,640,460,0,180);

                // Horca decorativa
                g2.setColor(EstiloUI.MADERA_OSCURA);
                g2.setStroke(new BasicStroke(8,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                g2.drawLine(80,520,80,310); g2.drawLine(50,520,110,520);
                g2.drawLine(80,310,140,310);
                g2.setStroke(new BasicStroke(3));
                g2.setColor(new Color(180,150,80));
                g2.drawLine(140,310,140,340); g2.drawOval(132,338,16,16);

                // Antorchas
                drawAntorcha(g2,790,240); drawAntorcha(g2,45,240);

                // Bicho en la telaraña
                g2.setColor(new Color(30,30,30));
                g2.fillOval(20,15,12,8);

                // Suelo
                g2.setColor(new Color(38,28,18)); g2.fillRect(0,490,860,90);

                g2.dispose();
            }
            private void drawAntorcha(Graphics2D g2,int x,int y){
                g2.setColor(new Color(255,140,0,200)); g2.fillOval(x-10,y-28,20,32);
                g2.setColor(new Color(255,220,0,150)); g2.fillOval(x-6,y-36,12,24);
                g2.setColor(EstiloUI.MADERA_OSCURA); g2.setStroke(new BasicStroke(6));
                g2.drawLine(x,y,x,y+45); g2.setStroke(new BasicStroke(3));
                g2.drawLine(x,y+45,x+18,y+45);
            }
        };
        p.setOpaque(false);
        return p;
    }
}
