package jvmdipoo;

import java.awt.*;
import javax.swing.*;

/**
 * Pantalla de derrota: "FIN DEL JUEGO - EL VERDUGO HA GANADO".
 */
public class jvIntPerdedor extends JInternalFrame {

    private jvAhorcado parent;
    private String     palabraSecreta;

    public jvIntPerdedor(jvAhorcado parent, String palabraSecreta) {
        this.parent = parent;
        this.palabraSecreta = palabraSecreta;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        // Fondo negro / rojo oscuro como en las imágenes
        PanelFondo fondo = new PanelFondo(new Color(8,5,5), new Color(30,10,10));
        fondo.setLayout(new BorderLayout());

        JPanel dibujo = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Horca completa
                g2.setColor(EstiloUI.MADERA_CLARA);
                g2.setStroke(new BasicStroke(9,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                g2.drawLine(50,500,50,60);
                g2.drawLine(20,500,80,500);
                g2.drawLine(50,60,160,60);
                g2.setStroke(new BasicStroke(4));
                g2.setColor(new Color(200,170,90));
                g2.drawLine(160,60,160,95);

                // Muñeco colgado completo (6 errores)
                int bx=160, by=130;
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(5,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                // Cabeza
                g2.drawOval(bx-22,by,44,44);
                // Ojos X (muerto)
                g2.setColor(new Color(220,50,50));
                g2.setStroke(new BasicStroke(3));
                g2.drawLine(bx-12,by+10,bx-4,by+18); g2.drawLine(bx-4,by+10,bx-12,by+18);
                g2.drawLine(bx+4,by+10,bx+12,by+18); g2.drawLine(bx+12,by+10,bx+4,by+18);
                // Boca triste
                g2.drawArc(bx-10,by+28,20,12,0,180);
                // Cuerpo
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(5,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                g2.drawLine(bx,by+44,bx,by+160);
                // Brazos
                g2.drawLine(bx,by+75,bx-48,by+120);
                g2.drawLine(bx,by+75,bx+48,by+120);
                // Piernas
                g2.drawLine(bx,by+160,bx-38,by+230);
                g2.drawLine(bx,by+160,bx+38,by+230);

                g2.dispose();
            }
        };
        dibujo.setOpaque(false);
        dibujo.setPreferredSize(new Dimension(280,580));

        // Texto
        JPanel textPanel = new JPanel(null);
        textPanel.setOpaque(false);

        JLabel lbl1 = new JLabel("FÍN DEL JUEGO", SwingConstants.CENTER);
        lbl1.setFont(new Font("Monospaced", Font.BOLD, 40));
        lbl1.setForeground(new Color(220, 50, 50));
        lbl1.setBounds(0, 50, 560, 55);
        textPanel.add(lbl1);

        JLabel lbl2 = new JLabel("<html><center>EL<br>VERDUGO<br>HA GANADO</center></html>", SwingConstants.CENTER);
        lbl2.setFont(new Font("Monospaced", Font.BOLD, 40));
        lbl2.setForeground(new Color(220, 50, 50));
        lbl2.setBounds(0, 120, 560, 200);
        textPanel.add(lbl2);

        JLabel lblPalabra = new JLabel("La palabra era: " + palabraSecreta, SwingConstants.CENTER);
        lblPalabra.setFont(EstiloUI.fuenteMono(20));
        lblPalabra.setForeground(EstiloUI.CREMA);
        lblPalabra.setBounds(0, 330, 560, 30);
        textPanel.add(lblPalabra);

        // Botones
        JButton btnOtraVez = new JButton("¡UNA VEZ MÁS!") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setColor(getModel().isRollover() ? new Color(0,140,220) : new Color(0,100,200));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,
                        (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        btnOtraVez.setFont(EstiloUI.fuenteBoton(14));
        btnOtraVez.setOpaque(false); btnOtraVez.setContentAreaFilled(false);
        btnOtraVez.setBorderPainted(false); btnOtraVez.setFocusPainted(false);
        btnOtraVez.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnOtraVez.setBounds(20, 380, 180, 44);
        btnOtraVez.addActionListener(e -> parent.mostrarTema());

        JButton btnRendirse = new JButton("RENDIRSE") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setColor(getModel().isRollover() ? new Color(50,50,50) : new Color(20,20,20));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,
                        (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        btnRendirse.setFont(EstiloUI.fuenteBoton(14));
        btnRendirse.setOpaque(false); btnRendirse.setContentAreaFilled(false);
        btnRendirse.setBorderPainted(false); btnRendirse.setFocusPainted(false);
        btnRendirse.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRendirse.setBounds(220, 380, 160, 44);
        btnRendirse.addActionListener(e -> parent.mostrarModoJuego());

        textPanel.add(btnOtraVez);
        textPanel.add(btnRendirse);

        fondo.add(dibujo, BorderLayout.WEST);
        fondo.add(textPanel, BorderLayout.CENTER);
        setContentPane(fondo);
    }
}
