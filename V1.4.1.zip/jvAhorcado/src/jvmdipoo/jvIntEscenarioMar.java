package jvmdipoo;

import java.awt.*;
import javax.swing.*;

public class jvIntEscenarioMar extends JInternalFrame {

    private jvAhorcado parent;
    private int tema;

    public jvIntEscenarioMar(jvAhorcado parent, int tema) {
        this.parent = parent;
        this.tema   = tema;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        PanelFondo fondo = new PanelFondo(new Color(5,10,25), new Color(8,20,45));
        fondo.setLayout(new BorderLayout());

        // Titulo
        JPanel panelTitulo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelTitulo.setOpaque(false);
        panelTitulo.setBorder(BorderFactory.createEmptyBorder(20,0,0,0));
        JPanel perg = EstiloUI.panelPergamino();
        perg.setLayout(new FlowLayout());
        perg.setBorder(BorderFactory.createEmptyBorder(10,40,10,40));
        JLabel lblTit = new JLabel("Escenario: Naufragio  |  MEDIA");
        lblTit.setFont(EstiloUI.fuenteTitulo(24));
        lblTit.setForeground(new Color(60,30,5));
        perg.add(lblTit);
        panelTitulo.add(perg);

        // Imagen del mapa
        JPanel mapa = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Cielo tormentoso
                g2.setPaint(new GradientPaint(0,0,new Color(15,15,40),0,getHeight(),new Color(10,35,70)));
                g2.fillRect(0,0,getWidth(),getHeight());

                // Nubes
                g2.setColor(new Color(30,30,60,200));
                g2.fillOval(20,10,120,50); g2.fillOval(80,5,160,60);
                g2.fillOval(300,15,100,40); g2.fillOval(500,8,140,55);
                g2.fillOval(650,12,120,45);

                // Rayo
                g2.setColor(new Color(255,240,100,200));
                g2.setStroke(new BasicStroke(3));
                g2.drawLine(130,55,115,100); g2.drawLine(115,100,130,100); g2.drawLine(130,100,110,155);

                // Mar
                g2.setColor(new Color(10,50,110));
                g2.fillRect(0,getHeight()-120,getWidth(),120);
                g2.setColor(new Color(20,80,150));
                for(int ox=0;ox<getWidth();ox+=60)
                    g2.fillArc(ox,getHeight()-130,60,30,0,180);
                g2.setColor(new Color(80,150,200,80));
                for(int ox=20;ox<getWidth();ox+=55)
                    g2.fillArc(ox,getHeight()-118,44,18,0,180);

                // Mastil / horca pirata
                int mx = 500;
                g2.setColor(new Color(100,60,20));
                g2.setStroke(new BasicStroke(10, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(mx,getHeight()-120,mx,60);
                g2.drawLine(mx,60,mx+140,60);
                g2.setColor(new Color(180,150,100,150));
                g2.fillPolygon(new int[]{mx,mx,mx+135}, new int[]{60,220,60}, 3);
                g2.setColor(new Color(180,150,70));
                g2.setStroke(new BasicStroke(4));
                g2.drawLine(mx+140,60,mx+140,110);
                g2.setColor(new Color(220,200,170));
                g2.fillOval(mx+118,110,44,44);
                g2.setColor(new Color(190,170,140));
                g2.setStroke(new BasicStroke(4));
                g2.drawLine(mx+140,154,mx+140,240);
                g2.drawLine(mx+140,175,mx+100,215);
                g2.drawLine(mx+140,175,mx+180,215);
                g2.drawLine(mx+140,240,mx+110,300);
                g2.drawLine(mx+140,240,mx+170,300);

                // Guiones
                g2.setColor(new Color(150,210,240));
                g2.setStroke(new BasicStroke(3));
                for(int i=0;i<9;i++) g2.drawLine(50+i*38,200,82+i*38,200);

                // Texto dificultad
                g2.setColor(new Color(100,180,255));
                g2.setFont(new Font("SansSerif", Font.BOLD, 22));
                g2.drawString("Dificultad: MEDIA", 50, 100);
                g2.setColor(new Color(180,180,180));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 16));
                g2.drawString("Palabras largas  |  6 intentos", 50, 130);

                g2.dispose();
            }
        };
        mapa.setPreferredSize(new Dimension(860, 350));
        mapa.setOpaque(true);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setOpaque(false);

        JButton btnJugar = EstiloUI.botonMadera("▶  Jugar en Naufragio");
        btnJugar.setPreferredSize(new Dimension(260, 52));
        btnJugar.setFont(EstiloUI.fuenteBoton(18));
        btnJugar.addActionListener(e -> parent.mostrarJuego(tema, 1, 1));

        JButton btnVolver = EstiloUI.botonMadera("← Volver");
        btnVolver.setPreferredSize(new Dimension(160, 52));
        btnVolver.setFont(EstiloUI.fuenteBoton(18));
        btnVolver.addActionListener(e -> parent.mostrarEscenario(tema));

        panelBotones.add(btnVolver);
        panelBotones.add(btnJugar);

        fondo.add(panelTitulo,  BorderLayout.NORTH);
        fondo.add(mapa,         BorderLayout.CENTER);
        fondo.add(panelBotones, BorderLayout.SOUTH);
        setContentPane(fondo);
        pack();
    }
}
