package jvmdipoo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Clase controladora del juego del ahorcado.
 * Maneja la lógica: palabras, letras adivinadas, errores.
 */
public class clsControlAhorcado {

    // ── Constantes ──────────────────────────────────────────────────────────
    public static int MAX_ERRORES = 6;   // cabeza, cuerpo, brazo-izq, brazo-der, pierna-izq, pierna-der

    // ── Banco de palabras por tema ───────────────────────────────────────────
    private static final String[][] PALABRAS = {
        // OBJETOS (índice 0)
        {"TELEFONO","COMPUTADORA","SILLA","LAMPARA","ESPEJO","VENTANA",
         "RELOJ","MOCHILA","ZAPATO","CAMARA","TECLADO","AUDIFONO",
         "BORRADOR","CUADERNO","PARAGUAS","BOTELLA","ESCALERA","PINTURA"},
        // CULTURA GENERAL (índice 1)
        {"PIRAMIDE","OLIMPIADAS","REVOLUCION","CONTINENTE","UNIVERSO",
         "DEMOCRACIA","CONSTITUCION","PATRIMONIO","CIVILIZACION","FILOSOFIA",
         "ASTRONOMIA","ECONOMIA","LITERATURA","GEOGRAFIA","HISTORIA","MUSICA"},
        // CIENCIA (índice 2)
        {"FOTOSINTESIS","GRAVEDAD","ATOMO","MOLECULA","CELULA",
         "EVOLUCION","QUIMICA","FISICA","BIOLOGIA","ECOSISTEMA",
         "NEUTRON","PROTONA","ENERGIA","MAGNETISMO","RADIACION","GEOLOGIA"}
    };

    // ── Estado del juego ─────────────────────────────────────────────────────
    private String   palabraSecreta;
    private char[]   letrasAdivinadas;
    private List<Character> letrasUsadas;
    private int      errores;
    private int      tema;        // 0=Objetos, 1=Cultura, 2=Ciencia
    private String   nombreJugador;

    // ── Constructor ──────────────────────────────────────────────────────────
    public clsControlAhorcado() {
        letrasUsadas = new ArrayList<>();
        errores = 0;
    }

    // ── Iniciar una partida nueva ────────────────────────────────────────────
public void iniciarJuego(int tema, String nombreJugador, int dificultad) {
    this.tema = tema;
    this.nombreJugador = nombreJugador;
    this.errores = 0;
    this.letrasUsadas = new ArrayList<>();

    // Ajustar intentos según dificultad
    if (dificultad == 2) {
        MAX_ERRORES = 3;  // Bosque: difícil, pocos intentos
    } else {
        MAX_ERRORES = 6;  // Mazmorra y Mar: normal
    }

    // Filtrar palabras por longitud según dificultad
    String[] listaTema = PALABRAS[tema];
    List<String> filtradas = new ArrayList<>();
    for (String p : listaTema) {
        if (dificultad == 0 && p.length() <= 6) filtradas.add(p);       // Fácil: cortas
        else if (dificultad == 1 && p.length() >= 9) filtradas.add(p);  // Media: largas
        else if (dificultad == 2 && p.length() >= 9) filtradas.add(p);  // Difícil: largas
    }
    // Si no hay palabras que cumplan el filtro, usar todas (por seguridad)
    if (filtradas.isEmpty()) filtradas = Arrays.asList(listaTema);

    Random rnd = new Random();
    this.palabraSecreta = filtradas.get(rnd.nextInt(filtradas.size()));
    this.letrasAdivinadas = new char[palabraSecreta.length()];
    Arrays.fill(this.letrasAdivinadas, '_');
}

    // ── Intentar una letra ───────────────────────────────────────────────────
    // Retorna: true si la letra estaba en la palabra, false si no
    public boolean intentarLetra(char letra) {
        letra = Character.toUpperCase(letra);
        if (letrasUsadas.contains(letra)) return true; // ya intentada, ignorar

        letrasUsadas.add(letra);
        boolean acierto = false;

        for (int i = 0; i < palabraSecreta.length(); i++) {
            if (palabraSecreta.charAt(i) == letra) {
                letrasAdivinadas[i] = letra;
                acierto = true;
            }
        }
        if (!acierto) errores++;
        return acierto;
    }

    // ── Consultas de estado ──────────────────────────────────────────────────
    public boolean juegoGanado() {
        for (char c : letrasAdivinadas) {
            if (c == '_') return false;
        }
        return true;
    }

    public boolean juegoPerdido() {
        return errores >= MAX_ERRORES;
    }

    public boolean letraYaUsada(char letra) {
        return letrasUsadas.contains(Character.toUpperCase(letra));
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public String getPalabraSecreta()   { return palabraSecreta; }
    public int    getErrores()          { return errores; }
    public int    getTema()             { return tema; }
    public String getNombreJugador()    { return nombreJugador; }

    /** Devuelve la palabra con guiones: "_ A _ _ _" */
    public String getDisplayPalabra() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < letrasAdivinadas.length; i++) {
            if (i > 0) sb.append(' ');
            sb.append(letrasAdivinadas[i]);
        }
        return sb.toString();
    }

    public List<Character> getLetrasUsadas() { return letrasUsadas; }

    public static String nombreTema(int t) {
        switch (t) {
            case 0: return "OBJETOS";
            case 1: return "CULTURA GENERAL";
            case 2: return "CIENCIA";
            default: return "";
        }
    }
}
