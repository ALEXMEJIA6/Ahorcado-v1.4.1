package jvmdipoo;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * Clase utilitaria con colores, fuentes y fábrica de botones estilo medieval.
 */
public class EstiloUI {

    // ── Paleta ───────────────────────────────────────────────────────────────
    public static final Color FONDO_OSCURO   = new Color(28, 18, 10);
    public static final Color FONDO_MEDIO    = new Color(55, 35, 20);
    public static final Color MADERA_OSCURA  = new Color(90, 55, 20);
    public static final Color MADERA_CLARA   = new Color(160, 100, 40);
    public static final Color DORADO         = new Color(230, 180, 60);
    public static final Color DORADO_CLARO   = new Color(255, 220, 100);
    public static final Color ROJO_SANGRE    = new Color(180, 30, 30);
    public static final Color CREMA          = new Color(245, 230, 190);
    public static final Color GRIS_PIEDRA    = new Color(130, 120, 110);
    public static final Color VERDE_MUSGO    = new Color(60, 90, 40);

    // ── Fuentes ──────────────────────────────────────────────────────────────
    public static Font fuenteTitulo(float size) {
        return new Font("Serif", Font.BOLD, (int) size);
    }

    public static Font fuenteBoton(float size) {
        return new Font("SansSerif", Font.BOLD, (int) size);
    }

    public static Font fuenteMono(float size) {
        return new Font("Monospaced", Font.BOLD, (int) size);
    }

    // ── Fábrica de botones estilo madera ─────────────────────────────────────
    public static JButton botonMadera(String texto) {
        JButton btn = new JButton(texto) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                Color top = getModel().isRollover()
                        ? new Color(200, 130, 50)
                        : MADERA_CLARA;
                Color bot = getModel().isRollover()
                        ? new Color(130, 75, 20)
                        : MADERA_OSCURA;

                GradientPaint gp = new GradientPaint(0, 0, top, 0, getHeight(), bot);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);

                // borde dorado
                g2.setColor(DORADO);
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 14, 14);

                // texto
                g2.setColor(CREMA);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth()  - fm.stringWidth(getText())) / 2;
                int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                // sombra
                g2.setColor(new Color(0,0,0,120));
                g2.drawString(getText(), tx+1, ty+1);
                g2.setColor(CREMA);
                g2.drawString(getText(), tx, ty);

                g2.dispose();
            }
        };
        btn.setFont(fuenteBoton(16));
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(280, 48));
        return btn;
    }

    // ── Etiqueta con sombra ──────────────────────────────────────────────────
    public static JLabel etiquetaTitulo(String texto, float size, Color color) {
        JLabel lbl = new JLabel(texto, SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                        RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth() - fm.stringWidth(getText())) / 2;
                int ty = fm.getAscent();
                // sombra
                g2.setColor(new Color(0,0,0,160));
                g2.drawString(getText(), tx+2, ty+2);
                // texto
                g2.setColor(getForeground());
                g2.drawString(getText(), tx, ty);
                g2.dispose();
            }
        };
        lbl.setFont(fuenteTitulo(size));
        lbl.setForeground(color);
        return lbl;
    }

    // ── Panel estilo pergamino ───────────────────────────────────────────────
    public static JPanel panelPergamino() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0,0,new Color(210,180,120),0,getHeight(),new Color(180,140,80));
                g2.setPaint(gp);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),20,20);
                g2.setColor(new Color(120,80,30));
                g2.setStroke(new BasicStroke(3f));
                g2.drawRoundRect(2,2,getWidth()-4,getHeight()-4,20,20);
                g2.dispose();
            }
        };
        panel.setOpaque(false);
        return panel;
    }
}
