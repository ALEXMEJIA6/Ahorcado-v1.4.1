package jvmdipoo;

import java.awt.*;
import javax.swing.*;

/**
 * Pantalla para que el usuario ingrese su nombre.
 */
public class jvIntCrearUsuario extends JInternalFrame {

    private jvAhorcado parent;

    public jvIntCrearUsuario(jvAhorcado parent) {
        this.parent = parent;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        PanelFondo fondo = new PanelFondo(new Color(18,10,5), new Color(40,22,10));
        fondo.setLayout(new BorderLayout());

        // Panel de fondo con decoración
        JPanel decoracion = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Arco de piedra
                g2.setColor(new Color(70,60,50));
                g2.fillArc(130,20,600,400, 0, 180);
                g2.setColor(new Color(90,78,65));
                g2.setStroke(new BasicStroke(10));
                g2.drawArc(130,20,600,400, 0, 180);

                // Bloques de piedra del arco
                g2.setColor(new Color(80,68,55));
                g2.setStroke(new BasicStroke(2));
                for (int i=0;i<12;i++) {
                    double ang = Math.PI * i / 11.0;
                    int cx = (int)(430 - 310*Math.cos(ang));
                    int cy = (int)(220 - 200*Math.sin(ang));
                    g2.drawRect(cx-15,cy-10,30,20);
                }

                // Antorchas
                drawAntorcha(g2, 160, 280);
                drawAntorcha(g2, 700, 280);

                // Telaraña esquina
                drawTelarana(g2, 0, 0, 80);

                // Suelo
                g2.setColor(new Color(45,35,25));
                g2.fillRect(0, getHeight()-60, getWidth(), 60);

                g2.dispose();
            }

            private void drawAntorcha(Graphics2D g2, int x, int y) {
                g2.setColor(new Color(255,140,0,200));
                g2.fillOval(x-10,y-30,20,35);
                g2.setColor(new Color(255,220,0,150));
                g2.fillOval(x-6,y-38,12,25);
                g2.setColor(new Color(120,80,30));
                g2.setStroke(new BasicStroke(6));
                g2.drawLine(x,y,x,y+45);
                g2.setStroke(new BasicStroke(3));
                g2.drawLine(x,y+45,x+18,y+45);
            }

            private void drawTelarana(Graphics2D g2, int cx, int cy, int r) {
                g2.setColor(new Color(180,180,180,100));
                g2.setStroke(new BasicStroke(1));
                for (int i=0;i<8;i++) {
                    double ang = Math.PI/2 * i/7.0;
                    g2.drawLine(cx,(int)(cy+r*0),(int)(cx+r*Math.cos(ang)),(int)(cy+r*Math.sin(ang)));
                }
                for (int ring=1;ring<=4;ring++) {
                    int rr = ring*r/4;
                    g2.drawArc(cx-rr,cy-rr,rr*2,rr*2,0,90);
                }
            }
        };
        decoracion.setOpaque(false);

        // ── Pergamino central ────────────────────────────────────────────────
        JPanel pergamino = EstiloUI.panelPergamino();
        pergamino.setLayout(new BoxLayout(pergamino, BoxLayout.Y_AXIS));
        pergamino.setBorder(BorderFactory.createEmptyBorder(30,40,30,40));

        JLabel lblTitulo = new JLabel("crea tu nombre de usuario", SwingConstants.CENTER);
        lblTitulo.setFont(EstiloUI.fuenteTitulo(24));
        lblTitulo.setForeground(new Color(80,45,10));
        lblTitulo.setAlignmentX(CENTER_ALIGNMENT);
        pergamino.add(lblTitulo);
        pergamino.add(Box.createVerticalStrut(20));

        JTextField txtNombre = new JTextField(18);
        txtNombre.setFont(EstiloUI.fuenteMono(20));
        txtNombre.setHorizontalAlignment(JTextField.CENTER);
        txtNombre.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(EstiloUI.MADERA_OSCURA, 2),
                BorderFactory.createEmptyBorder(6,10,6,10)));
        txtNombre.setBackground(new Color(240,225,185));
        txtNombre.setForeground(new Color(60,30,10));
        txtNombre.setMaximumSize(new Dimension(300,45));
        txtNombre.setAlignmentX(CENTER_ALIGNMENT);
        pergamino.add(txtNombre);
        pergamino.add(Box.createVerticalStrut(20));

        JButton btnAceptar = EstiloUI.botonMadera("Aceptar");
        btnAceptar.setAlignmentX(CENTER_ALIGNMENT);
        btnAceptar.setPreferredSize(new Dimension(200,44));
        btnAceptar.setMaximumSize(new Dimension(200,44));
        btnAceptar.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(null,
                        "Por favor escribe tu nombre de usuario.",
                        "Campo vacío", JOptionPane.WARNING_MESSAGE);
                return;
            }
            parent.setNombreJugador(nombre);
            parent.mostrarModoJuego();
        });
        pergamino.add(btnAceptar);

        // Centrar el pergamino
        pergamino.setPreferredSize(new Dimension(380, 220));

        JPanel contenedor = new JPanel(new GridBagLayout());
        contenedor.setOpaque(false);
        contenedor.add(pergamino);

        // Capas: decoracion atrás, contenedor adelante
        JLayeredPane capas = new JLayeredPane();
        capas.setPreferredSize(new Dimension(860,580));
        decoracion.setBounds(0,0,860,580);
        contenedor.setBounds(0,0,860,580);
        capas.add(decoracion, JLayeredPane.DEFAULT_LAYER);
        capas.add(contenedor, JLayeredPane.PALETTE_LAYER);

        fondo.add(capas, BorderLayout.CENTER);
        setContentPane(fondo);
    }
}
