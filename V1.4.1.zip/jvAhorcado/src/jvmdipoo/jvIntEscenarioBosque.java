package jvmdipoo;

import java.awt.*;
import javax.swing.*;

public class jvIntEscenarioBosque extends JInternalFrame {

    private jvAhorcado parent;
    private int tema;

    public jvIntEscenarioBosque(jvAhorcado parent, int tema) {
        this.parent = parent;
        this.tema   = tema;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        PanelFondo fondo = new PanelFondo(new Color(5,15,5), new Color(10,30,10));
        fondo.setLayout(new BorderLayout());

        // Titulo
        JPanel panelTitulo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelTitulo.setOpaque(false);
        panelTitulo.setBorder(BorderFactory.createEmptyBorder(20,0,0,0));
        JPanel perg = EstiloUI.panelPergamino();
        perg.setLayout(new FlowLayout());
        perg.setBorder(BorderFactory.createEmptyBorder(10,40,10,40));
        JLabel lblTit = new JLabel("Escenario: Bosque  |  DIFICIL");
        lblTit.setFont(EstiloUI.fuenteTitulo(24));
        lblTit.setForeground(new Color(60,30,5));
        perg.add(lblTit);
        panelTitulo.add(perg);

        // Imagen del mapa
        JPanel mapa = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Fondo bosque nocturno
                g2.setPaint(new GradientPaint(0,0,new Color(5,15,5),0,getHeight(),new Color(15,40,10)));
                g2.fillRect(0,0,getWidth(),getHeight());

                // Luna
                g2.setColor(new Color(220,230,180,200));
                g2.fillOval(680,15,70,70);
                g2.setColor(new Color(200,210,150,80));
                g2.fillOval(670,10,90,90);

                // Estrellas
                g2.setColor(new Color(255,255,200,180));
                int[][] estrellas = {{50,30},{120,20},{250,15},{400,25},{550,10},{750,35},{800,18}};
                for(int[] e : estrellas) { g2.fillOval(e[0],e[1],4,4); }

                // Arboles de fondo
                g2.setColor(new Color(10,30,8));
                for(int tx=0; tx<860; tx+=35){
                    int h = 100 + (tx % 60);
                    g2.fillRect(tx+8, getHeight()-h-30, 14, h+30);
                    g2.fillPolygon(
                        new int[]{tx, tx+15, tx+30},
                        new int[]{getHeight()-h-30, getHeight()-h-90, getHeight()-h-30}, 3);
                    g2.fillPolygon(
                        new int[]{tx+2, tx+15, tx+28},
                        new int[]{getHeight()-h-10, getHeight()-h-60, getHeight()-h-10}, 3);
                }

                // Suelo
                g2.setColor(new Color(20,50,15));
                g2.fillRect(0,getHeight()-30,getWidth(),30);

                // Horca de ramas
                int hx = 480;
                g2.setColor(new Color(70,40,15));
                g2.setStroke(new BasicStroke(12, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(hx, getHeight()-30, hx, 70);
                g2.drawLine(hx-30, getHeight()-30, hx+30, getHeight()-30);
                g2.drawLine(hx, 70, hx+160, 70);
                g2.setStroke(new BasicStroke(5));
                g2.drawLine(hx+30, 100, hx+160, 70);
                g2.setColor(new Color(140,100,40));
                g2.setStroke(new BasicStroke(4));
                g2.drawLine(hx+160,70,hx+160,120);
                g2.setColor(new Color(230,210,180));
                g2.fillOval(hx+138,120,44,44);
                g2.setColor(new Color(200,180,140));
                g2.setStroke(new BasicStroke(4));
                g2.drawLine(hx+160,164,hx+160,250);
                g2.drawLine(hx+160,185,hx+120,225);
                g2.drawLine(hx+160,185,hx+200,225);
                g2.drawLine(hx+160,250,hx+130,310);
                g2.drawLine(hx+160,250,hx+190,310);

                // Guiones
                g2.setColor(new Color(100,200,80));
                g2.setStroke(new BasicStroke(3));
                for(int i=0;i<9;i++) g2.drawLine(50+i*38,220,82+i*38,220);

                // Texto dificultad
                g2.setColor(new Color(255,100,100));
                g2.setFont(new Font("SansSerif", Font.BOLD, 22));
                g2.drawString("Dificultad: DIFICIL", 50, 100);
                g2.setColor(new Color(180,180,180));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 16));
                g2.drawString("Palabras largas  |  solo 3 intentos", 50, 130);

                g2.dispose();
            }
        };
        mapa.setPreferredSize(new Dimension(860, 350));
        mapa.setOpaque(true);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setOpaque(false);

        JButton btnJugar = EstiloUI.botonMadera("▶  Jugar en Bosque");
        btnJugar.setPreferredSize(new Dimension(260, 52));
        btnJugar.setFont(EstiloUI.fuenteBoton(18));
        btnJugar.addActionListener(e -> parent.mostrarJuego(tema, 2, 2));

        JButton btnVolver = EstiloUI.botonMadera("← Volver");
        btnVolver.setPreferredSize(new Dimension(160, 52));
        btnVolver.setFont(EstiloUI.fuenteBoton(18));
        btnVolver.addActionListener(e -> parent.mostrarEscenario(tema));

        panelBotones.add(btnVolver);
        panelBotones.add(btnJugar);

        fondo.add(panelTitulo,  BorderLayout.NORTH);
        fondo.add(mapa,         BorderLayout.CENTER);
        fondo.add(panelBotones, BorderLayout.SOUTH);
        setContentPane(fondo);
        pack();
    }
}
