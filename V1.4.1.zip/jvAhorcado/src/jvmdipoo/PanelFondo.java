package jvmdipoo;

import java.awt.*;
import javax.swing.JPanel;

/**
 * Panel reutilizable que pinta un degradado de fondo oscuro tipo mazmorra.
 * Se usa como base de todas las pantallas internas.
 */
public class PanelFondo extends JPanel {

    private Color c1, c2;

    public PanelFondo(Color c1, Color c2) {
        this.c1 = c1;
        this.c2 = c2;
        setOpaque(true);
    }

@Override
protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g.create();
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    GradientPaint gp = new GradientPaint(0, 0, c1, 0, getHeight(), c2);
    g2.setPaint(gp);
    g2.fillRect(0, 0, getWidth(), getHeight());
    g2.dispose();
}
}
