package jvmdipoo;

import java.awt.*;
import javax.swing.*;

public class jvIntEscenarioMazmorra extends JInternalFrame {

    private jvAhorcado parent;
    private int tema;

    public jvIntEscenarioMazmorra(jvAhorcado parent, int tema) {
        this.parent = parent;
        this.tema   = tema;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        PanelFondo fondo = new PanelFondo(new Color(15,10,5), new Color(38,20,8));
        fondo.setLayout(new BorderLayout());

        // Titulo
        JPanel panelTitulo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelTitulo.setOpaque(false);
        panelTitulo.setBorder(BorderFactory.createEmptyBorder(20,0,0,0));
        JPanel perg = EstiloUI.panelPergamino();
        perg.setLayout(new FlowLayout());
        perg.setBorder(BorderFactory.createEmptyBorder(10,40,10,40));
        JLabel lblTit = new JLabel("Escenario: Mazmorra  |  FACIL");
        lblTit.setFont(EstiloUI.fuenteTitulo(24));
        lblTit.setForeground(new Color(60,30,5));
        perg.add(lblTit);
        panelTitulo.add(perg);

        // Imagen del mapa
        JPanel mapa = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Fondo morado oscuro
                g2.setColor(new Color(30,15,40));
                g2.fillRect(0,0,getWidth(),getHeight());

                // Horca
                g2.setColor(new Color(180,130,60));
                g2.setStroke(new BasicStroke(8, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(200,400,200,80);
                g2.drawLine(160,400,240,400);
                g2.drawLine(200,80,340,80);
                g2.setStroke(new BasicStroke(4));
                g2.setColor(new Color(200,170,80));
                g2.drawLine(340,80,340,120);
                g2.setColor(new Color(230,210,180));
                g2.fillOval(320,120,40,40);
                g2.setStroke(new BasicStroke(4));
                g2.drawLine(340,160,340,250);
                g2.drawLine(340,180,300,230);
                g2.drawLine(340,180,380,230);
                g2.drawLine(340,250,310,320);
                g2.drawLine(340,250,370,320);

                // Guiones de la palabra
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(3));
                for(int i=0;i<6;i++) g2.drawLine(430+i*40,300,465+i*40,300);

                // Texto de dificultad
                g2.setColor(new Color(100,220,100));
                g2.setFont(new Font("SansSerif", Font.BOLD, 22));
                g2.drawString("Dificultad: FACIL", 380, 100);
                g2.setColor(new Color(180,180,180));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 16));
                g2.drawString("Palabras cortas  |  6 intentos", 380, 135);

                g2.dispose();
            }
        };
        mapa.setPreferredSize(new Dimension(860, 350));
        mapa.setOpaque(true);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setOpaque(false);

        JButton btnJugar = EstiloUI.botonMadera("▶  Jugar en Mazmorra");
        btnJugar.setPreferredSize(new Dimension(260, 52));
        btnJugar.setFont(EstiloUI.fuenteBoton(18));
        btnJugar.addActionListener(e -> parent.mostrarJuego(tema, 0, 0));

        JButton btnVolver = EstiloUI.botonMadera("← Volver");
        btnVolver.setPreferredSize(new Dimension(160, 52));
        btnVolver.setFont(EstiloUI.fuenteBoton(18));
        btnVolver.addActionListener(e -> parent.mostrarEscenario(tema));

        panelBotones.add(btnVolver);
        panelBotones.add(btnJugar);

        fondo.add(panelTitulo,   BorderLayout.NORTH);
        fondo.add(mapa,          BorderLayout.CENTER);
        fondo.add(panelBotones,  BorderLayout.SOUTH);
        setContentPane(fondo);
        pack();
    }
}
