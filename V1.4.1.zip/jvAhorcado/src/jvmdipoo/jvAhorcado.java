package jvmdipoo;

import java.awt.*;
import javax.swing.*;

/**
 * Ventana MDI principal "EL AHORCADO".
 * Contiene el JDesktopPane y orquesta el flujo de pantallas hijo.
 */
public class jvAhorcado extends JFrame {

    public JDesktopPane desktop;

    // Estado compartido entre pantallas
    private String nombreJugador = "";
    private clsControlAhorcado controlJuego;

    public jvAhorcado() {
        controlJuego = new clsControlAhorcado();
        inicializarVentana();
        // Primera pantalla: portada
        mostrarPortada();
    }

    private void inicializarVentana() {
        setTitle("EL AHORCADO");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 650);
        setLocationRelativeTo(null);
        setResizable(false);

        desktop = new JDesktopPane();
        desktop.setBackground(new Color(20, 20, 30));
        setContentPane(desktop);
    }

    // ── Métodos de navegación ────────────────────────────────────────────────

    public void mostrarPortada() {
        mostrarPantalla(new jvIntPortada(this));
    }

    public void mostrarCrearUsuario() {
        mostrarPantalla(new jvIntCrearUsuario(this));
    }

    public void mostrarModoJuego() {
        mostrarPantalla(new jvIntModoJuego(this));
    }

    public void mostrarTema() {
        mostrarPantalla(new jvIntTema(this));
    }

    public void mostrarEscenarioMazmorra(int tema) { mostrarPantalla(new jvIntEscenarioMazmorra(this, tema)); }
    public void mostrarEscenarioMar(int tema)      { mostrarPantalla(new jvIntEscenarioMar(this, tema)); }
    public void mostrarEscenarioBosque(int tema)   { mostrarPantalla(new jvIntEscenarioBosque(this, tema)); }

    public void mostrarEscenario(int tema) {
        mostrarPantalla(new jvIntEscenario(this, tema));
    }

    public void mostrarJuego(int tema, int escenario, int dificultad) {
        controlJuego.iniciarJuego(tema, nombreJugador, dificultad);
        mostrarPantalla(new jvIntJuego(this, controlJuego, escenario));
    }

    public void mostrarGanador() {
        mostrarPantalla(new jvIntGanador(this));
    }

    public void mostrarPerdedor() {
        mostrarPantalla(new jvIntPerdedor(this, controlJuego.getPalabraSecreta()));
    }

    // ── Helper: cierra la anterior, abre la nueva centrada con fade ──────────
    private void mostrarPantalla(JInternalFrame nueva) {
        // Cerrar todas las internas existentes
        for (JInternalFrame f : desktop.getAllFrames()) {
            try { f.setClosed(true); } catch (Exception e) { /* ignorar */ }
        }

        // Posicionar nueva centrada dentro del desktop
        desktop.add(nueva);
        Dimension dSize = desktop.getSize();
        Dimension fSize = nueva.getPreferredSize();
        int x = Math.max(0, (dSize.width  - fSize.width)  / 2);
        int y = Math.max(0, (dSize.height - fSize.height) / 2);
        nueva.setLocation(x, y);
        nueva.setSize(fSize);

        // Fade-in suave
        nueva.setVisible(true);
        aplicarFadeIn(nueva);

        try { nueva.setSelected(true); } catch (Exception e) { /* ignorar */ }
    }

    private void aplicarFadeIn(JInternalFrame frame) {
        // Simulamos fade-in animando la opacidad del contenido
        // (JInternalFrame no soporta setOpacity directamente, usamos Timer)
        final float[] alpha = {0f};
        Timer t = new Timer(30, null);
        t.addActionListener(e -> {
            alpha[0] += 0.12f;
            if (alpha[0] >= 1f) {
                alpha[0] = 1f;
                t.stop();
            }
            frame.repaint();
        });
        t.start();
    }

    // ── Getters / Setters ────────────────────────────────────────────────────
    public String getNombreJugador()                  { return nombreJugador; }
    public void   setNombreJugador(String nombre)     { this.nombreJugador = nombre; }
    public clsControlAhorcado getControlJuego()       { return controlJuego; }
}
