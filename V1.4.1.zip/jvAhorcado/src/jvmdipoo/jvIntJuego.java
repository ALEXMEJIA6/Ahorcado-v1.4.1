package jvmdipoo;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

/**
 * Pantalla principal del juego del ahorcado.
 * Dibuja: horca, palabra, teclado de letras, partes del cuerpo según errores.
 */
public class jvIntJuego extends JInternalFrame {

    private jvAhorcado           parent;
    private clsControlAhorcado   ctrl;
    private int                  escenario;

    // Componentes dinámicos
    private JLabel  lblPalabra;
    private JLabel  lblMensaje;
    private JLabel  lblTema;
    private JPanel  panelHorca;
    private Map<Character, JButton> mapaBotones = new LinkedHashMap<>();

    public jvIntJuego(jvAhorcado parent, clsControlAhorcado ctrl, int escenario) {
        this.parent    = parent;
        this.ctrl      = ctrl;
        this.escenario = escenario;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        // Fondo morado oscuro (estilo mapa 1 de las imágenes)
        Color bgOscuro, bgMedio;

        if (escenario == 1) {
            // Naufragio: azul marino
            bgOscuro = new Color(5, 15, 40);
            bgMedio  = new Color(10, 30, 70);
        } else if (escenario == 2) {
            // Bosque: verde oscuro
            bgOscuro = new Color(5, 20, 5);
            bgMedio  = new Color(15, 40, 10);
        } else {
            // Mazmorra (default): morado
            bgOscuro = new Color(28, 15, 45);
            bgMedio  = new Color(45, 25, 70);
}

        PanelFondo fondo = new PanelFondo(bgOscuro, bgMedio);
        fondo.setLayout(new BorderLayout(8, 8));
        fondo.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));

        // ── Barra superior: tema + jugador + errores ─────────────────────────
        JPanel barraTop = new JPanel(new BorderLayout());
        barraTop.setOpaque(false);

        lblTema = new JLabel("Tema: " + clsControlAhorcado.nombreTema(ctrl.getTema())
                + "   |   Jugador: " + ctrl.getNombreJugador());
        lblTema.setFont(EstiloUI.fuenteBoton(14));
        lblTema.setForeground(EstiloUI.CREMA);
        barraTop.add(lblTema, BorderLayout.WEST);

        lblMensaje = new JLabel("¡Adivina la palabra!", SwingConstants.RIGHT);
        lblMensaje.setFont(EstiloUI.fuenteBoton(14));
        lblMensaje.setForeground(EstiloUI.DORADO);
        barraTop.add(lblMensaje, BorderLayout.EAST);

        // ── Panel central: horca (izq) + columna derecha (palabra+teclado) ───
        JPanel panelCentro = new JPanel(new BorderLayout(16, 0));
        panelCentro.setOpaque(false);

        // Horca dibujada a mano
        panelHorca = buildPanelHorca();
        panelCentro.add(panelHorca, BorderLayout.WEST);

        // Columna derecha
        JPanel colDer = new JPanel(new BorderLayout(0, 14));
        colDer.setOpaque(false);

        // Palabra con guiones
        lblPalabra = new JLabel(ctrl.getDisplayPalabra(), SwingConstants.CENTER);
        lblPalabra.setFont(EstiloUI.fuenteMono(34));
        lblPalabra.setForeground(Color.WHITE);
        lblPalabra.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, EstiloUI.DORADO));
        colDer.add(lblPalabra, BorderLayout.NORTH);

        // Teclado de letras
        JPanel teclado = buildTeclado();
        colDer.add(teclado, BorderLayout.CENTER);

        panelCentro.add(colDer, BorderLayout.CENTER);

        fondo.add(barraTop,    BorderLayout.NORTH);
        fondo.add(panelCentro, BorderLayout.CENTER);

        setContentPane(fondo);
        
    }

    // ── Horca dibujada en un JPanel personalizado ────────────────────────────
    private JPanel buildPanelHorca() {
        JPanel p = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int errores = ctrl.getErrores();
                int cx = 180; // centro X del cuerpo

                // ── Estructura horca ─────────────────────────────────────────
                g2.setColor(EstiloUI.MADERA_CLARA);
                g2.setStroke(new BasicStroke(10, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                // Base
                g2.drawLine(30, 440, 220, 440);
                // Palo vertical
                g2.drawLine(80, 440, 80, 50);
                // Palo horizontal
                g2.drawLine(80, 50, 200, 50);
                // Soporte diagonal
                g2.setStroke(new BasicStroke(6, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(80, 110, 130, 50);
                // Cuerda
                g2.setColor(new Color(200, 170, 90));
                g2.setStroke(new BasicStroke(4));
                g2.drawLine(200, 50, 200, 90);

                // ── Figura del ahorcado (se dibuja según errores) ─────────────
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                if (errores >= 1) { // Cabeza
                    g2.drawOval(cx - 22, 90, 44, 44);
                }
                if (errores >= 2) { // Cuerpo
                    g2.drawLine(cx, 134, cx, 260);
                }
                if (errores >= 3) { // Brazo izquierdo
                    g2.drawLine(cx, 160, cx - 45, 210);
                }
                if (errores >= 4) { // Brazo derecho
                    g2.drawLine(cx, 160, cx + 45, 210);
                }
                if (errores >= 5) { // Pierna izquierda
                    g2.drawLine(cx, 260, cx - 40, 340);
                }
                if (errores >= 6) { // Pierna derecha
                    g2.drawLine(cx, 260, cx + 40, 340);
                }

                // Cara triste si perdió
                if (errores >= 6) {
                    g2.setColor(new Color(255, 80, 80));
                    g2.setStroke(new BasicStroke(3));
                    // ojos X
                    g2.drawLine(cx-12, 100, cx-6,  106);
                    g2.drawLine(cx-6,  100, cx-12, 106);
                    g2.drawLine(cx+6,  100, cx+12, 106);
                    g2.drawLine(cx+12, 100, cx+6,  106);
                    // boca curva hacia abajo
                    g2.drawArc(cx-10, 118, 20, 14, 0, -180);
                } else if (ctrl.juegoGanado()) {
                    // Cara feliz
                    g2.setColor(new Color(80, 220, 80));
                    g2.setStroke(new BasicStroke(3));
                    g2.fillOval(cx-10, 100, 7, 7);
                    g2.fillOval(cx+3,  100, 7, 7);
                    g2.drawArc(cx-10, 110, 20, 14, 0, -180);
                    g2.drawArc(cx-10, 112, 20, 12, 180, 180);
                }

                // Contador de errores
                g2.setFont(EstiloUI.fuenteBoton(16));
                g2.setColor(errores >= 4 ? new Color(255,80,80) : EstiloUI.CREMA);
                g2.drawString("Errores: " + errores + " / " + clsControlAhorcado.MAX_ERRORES,
                        10, 470);

                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setPreferredSize(new Dimension(310, 490));
        return p;
    }

    // ── Teclado de letras ────────────────────────────────────────────────────
    private JPanel buildTeclado() {
        JPanel base = new JPanel(new BorderLayout());
        base.setOpaque(false);

        String[] filas = {"ABCDEF", "GHIJKL", "MNOPQR", "STUVWX", "YZ"};

        JPanel grid = new JPanel();
        grid.setLayout(new BoxLayout(grid, BoxLayout.Y_AXIS));
        grid.setOpaque(false);

        for (String fila : filas) {
            JPanel panelFila = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 4));
            panelFila.setOpaque(false);
            for (char c : fila.toCharArray()) {
                JButton btn = crearBotonLetra(c);
                mapaBotones.put(c, btn);
                panelFila.add(btn);
            }
            grid.add(panelFila);
        }

        base.add(grid, BorderLayout.NORTH);
        return base;
    }

    private JButton crearBotonLetra(char letra) {
        JButton btn = new JButton(String.valueOf(letra)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                boolean usada = ctrl.letraYaUsada(letra);
                Color bg, fg;
                if (!isEnabled() || usada) {
                    bg = new Color(50, 40, 65);
                    fg = new Color(120, 100, 140);
                } else if (getModel().isRollover()) {
                    bg = new Color(100, 70, 150);
                    fg = Color.WHITE;
                } else {
                    bg = new Color(70, 50, 110);
                    fg = EstiloUI.CREMA;
                }
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(new Color(140, 110, 200));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                g2.setColor(fg);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(),
                        (getWidth()-fm.stringWidth(getText()))/2,
                        (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        btn.setFont(EstiloUI.fuenteBoton(16));
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(50, 42));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addActionListener(e -> procesarLetra(letra, btn));
        return btn;
    }

    // ── Lógica al pulsar una letra ───────────────────────────────────────────
    private void procesarLetra(char letra, JButton btn) {
        if (ctrl.letraYaUsada(letra)) return;

        boolean acierto = ctrl.intentarLetra(letra);

        // Deshabilitar botón
        btn.setEnabled(false);
        btn.repaint();

        // Actualizar palabra
        lblPalabra.setText(ctrl.getDisplayPalabra());

        // Actualizar horca
        panelHorca.repaint();

        // Mensaje
        if (acierto) {
            lblMensaje.setForeground(new Color(80, 220, 80));
            lblMensaje.setText("¡Correcto!");
        } else {
            lblMensaje.setForeground(new Color(220, 80, 80));
            lblMensaje.setText("¡Incorrecto! Errores: " + ctrl.getErrores());
        }

        // Revisar fin de juego
        if (ctrl.juegoGanado()) {
            panelHorca.repaint();
            javax.swing.Timer t = new javax.swing.Timer(900, ev -> parent.mostrarGanador());
            t.setRepeats(false);
            t.start();
        } else if (ctrl.juegoPerdido()) {
            panelHorca.repaint();
            bloquearTeclado();
            javax.swing.Timer t = new javax.swing.Timer(900, ev -> parent.mostrarPerdedor());
            t.setRepeats(false);
            t.start();
        }
    }

    private void bloquearTeclado() {
        for (JButton b : mapaBotones.values()) {
            b.setEnabled(false);
            b.repaint();
        }
    }
}
