package jvmdipoo;

import java.awt.*;
import javax.swing.*;

/**
 * Pantalla de victoria: "¡INCREÍBLE! TE SALVASTE POR POCO".
 */
public class jvIntGanador extends JInternalFrame {

    private jvAhorcado parent;

    public jvIntGanador(jvAhorcado parent) {
        this.parent = parent;
        putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        setClosable(false); setMaximizable(false); setIconifiable(false); setResizable(false);
        setPreferredSize(new Dimension(860, 580));
        inicializar();
    }

    private void inicializar() {
        // Fondo verde oscuro como en las imágenes
        PanelFondo fondo = new PanelFondo(new Color(10, 60, 20), new Color(20, 100, 35));
        fondo.setLayout(new BorderLayout());

        JPanel dibujo = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Horca vacía (se salvó)
                g2.setColor(EstiloUI.MADERA_CLARA);
                g2.setStroke(new BasicStroke(9,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                g2.drawLine(60,500,60,80);
                g2.drawLine(30,500,90,500);
                g2.drawLine(60,80,160,80);
                g2.setStroke(new BasicStroke(4));
                g2.setColor(new Color(200,170,90));
                g2.drawLine(160,80,160,120); // cuerda suelta

                // Muñeco corriendo feliz (izquierda)
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(5,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                int bx=220, by=300;
                // Cabeza
                g2.fillOval(bx-22,by-55,44,44);
                // Sonrisa
                g2.setColor(new Color(255,80,80));
                g2.setStroke(new BasicStroke(3));
                g2.drawArc(bx-10,by-30,20,12,0,-180);
                // Ojos
                g2.fillOval(bx-10,by-48,6,6); g2.fillOval(bx+4,by-48,6,6);
                // Cuerpo
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(5,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                g2.drawLine(bx,by-11,bx,by+60);
                // Brazo izq (levantado celebrando)
                g2.drawLine(bx,by+10,bx-50,by-20);
                // Brazo der (levantado)
                g2.drawLine(bx,by+10,bx+50,by-20);
                // Pierna izq (corriendo)
                g2.drawLine(bx,by+60,bx-35,by+110);
                // Pierna der
                g2.drawLine(bx,by+60,bx+30,by+110);

                g2.dispose();
            }
        };
        dibujo.setOpaque(false);
        dibujo.setPreferredSize(new Dimension(340,580));

        // Texto lado derecho
        JPanel textPanel = new JPanel(null);
        textPanel.setOpaque(false);

        JLabel lbl1 = new JLabel("¡INCREÍBLE!", SwingConstants.CENTER);
        lbl1.setFont(new Font("Monospaced", Font.BOLD, 52));
        lbl1.setForeground(Color.WHITE);
        lbl1.setBounds(0, 60, 500, 70);
        textPanel.add(lbl1);

        JLabel lbl2 = new JLabel("<html><center>TE<br>SALVASTE<br>POR POCO</center></html>", SwingConstants.CENTER);
        lbl2.setFont(new Font("Monospaced", Font.BOLD, 42));
        lbl2.setForeground(Color.WHITE);
        lbl2.setBounds(0, 140, 500, 200);
        textPanel.add(lbl2);

        // Botones
        JButton btnOtraVez = new JButton("¡UNA VEZ MÁS!") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setColor(getModel().isRollover() ? new Color(0,140,220) : new Color(0,100,200));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,
                        (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        btnOtraVez.setFont(EstiloUI.fuenteBoton(14));
        btnOtraVez.setOpaque(false); btnOtraVez.setContentAreaFilled(false);
        btnOtraVez.setBorderPainted(false); btnOtraVez.setFocusPainted(false);
        btnOtraVez.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnOtraVez.setBounds(20, 370, 180, 44);
        btnOtraVez.addActionListener(e -> parent.mostrarTema());

        JButton btnRendirse = new JButton("RENDIRSE") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setColor(getModel().isRollover() ? new Color(50,50,50) : new Color(20,20,20));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm=g2.getFontMetrics();
                g2.drawString(getText(),(getWidth()-fm.stringWidth(getText()))/2,
                        (getHeight()+fm.getAscent()-fm.getDescent())/2);
                g2.dispose();
            }
        };
        btnRendirse.setFont(EstiloUI.fuenteBoton(14));
        btnRendirse.setOpaque(false); btnRendirse.setContentAreaFilled(false);
        btnRendirse.setBorderPainted(false); btnRendirse.setFocusPainted(false);
        btnRendirse.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRendirse.setBounds(220, 370, 160, 44);
        btnRendirse.addActionListener(e -> parent.mostrarModoJuego());

        textPanel.add(btnOtraVez);
        textPanel.add(btnRendirse);

        fondo.add(dibujo, BorderLayout.WEST);
        fondo.add(textPanel, BorderLayout.CENTER);
        setContentPane(fondo);
    }
}
