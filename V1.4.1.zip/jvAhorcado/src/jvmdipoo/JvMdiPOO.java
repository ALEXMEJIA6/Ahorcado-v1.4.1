package jvmdipoo;

public class JvMdiPOO {
    public static void main(String[] args) {
        // Aplicar look Nimbus si está disponible
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) { /* usar look por defecto */ }

        java.awt.EventQueue.invokeLater(() -> {
            jvAhorcado ventanaPrincipal = new jvAhorcado();
            ventanaPrincipal.setVisible(true);
        });
    }
}
